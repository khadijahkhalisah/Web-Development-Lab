<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 4:24:50 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Book Session</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container mt-5">
        <div class="card shadow p-4 mx-auto" style="max-width: 500px;">
            <h2 class="mb-4">Book Session</h2>
            <form action="../BookSessionServlet" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="mb-3">
                    <label>Student Name:</label>
                    <input type="text" name="student_name" class="form-control" placeholder="e.g., Siti Khadijah Khalisah Binti Mohd Rsoli" required>
                </div>
                <div class="mb-3">
                    <label>Branch Location:</label>
                    <input type="text" name="branch_location" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Lesson Type:</label>
                    <input type="text" name="lesson_type" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success w-100">Book Session</button>
                <a href="../BookSessionServlet?action=view" class="btn btn-secondary w-100 mt-2">Back</a>
            </form>
        </div>
    </body>
</html>
