<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 4:39:51 PM
    Author     : MP2-4
--%>

<%@page import="com.lab.bean.SessionBean"%>
<%@page import="com.lab.controller.ScheduleServlet"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Schedule</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Training Sessions</h2>
        </div>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Session ID</th>
                    <th>Student Name</th>
                    <th>Branch Location</th>
                    <th>Lesson Type</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <%
                    List<SessionBean> list = (List<SessionBean>) request.getAttribute("subjectList");
                    if (list == null || list.isEmpty()) {
                %>
                    <tr><td colspan="4" class="text-center text-muted">No subjects registered yet.</td></tr>
                <%
                    } else {
                        int count = 1;
                        for (SessionBean sb : list) {
                %>
            </tbody>
        </table>
    </body>
</html>
