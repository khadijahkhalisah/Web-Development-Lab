/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.controller;

import com.lab.bean.SessionBean;
import com.lab.dao.SessionDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author MP2-4
 */
public class ScheduleServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("list".equals(action)){
                List<SessionBean> list = SessionDAO.getAllSessions();
                request.setAttribute("sessionList", list);
                request.getRequestDispatcher("schedule.jsp").forward(request, response);
            }
        }catch (Exception e){
            throw new ServletException(e);
        }
    }
}
