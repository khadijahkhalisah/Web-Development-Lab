/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.controller;

import com.lab.bean.SessionBean;
import com.lab.dao.SessionDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 *
 * @author MP2-4
 */
@WebServlet("/BookSessionServlet")
public class BookSessionServlet extends HttpServlet{
        private SessionDAO sessionDAO = new SessionDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)){
                SessionBean sb = new SessionBean();
                sb.setStudent_name(request.getParameter("student_name"));
                sb.getBranch_location(request.getParameter("branch_location"));
                sb.getLesson_type(request.getParameter("lesson_type"));
                sessionDAO.bookSession(sb);
                response.sendRedirect("ScheduleServlet?action=list");
            }
        } catch (Exception e){
            throw new ServletException(e);
        }
        
    }
}
