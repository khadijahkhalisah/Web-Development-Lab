/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.dao;
import com.lab.bean.SessionBean;
import java.sql.*;
import java.util.ArrayList;
import java.util.List; 
/**
 *
 * @author MP2-4
 */
public class SessionDAO {

    public static List<SessionBean> getAllSessions() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private Connection getConnection() throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/drivesmart_db","admin","admin123");
    }
    
    public boolean bookSession(SessionBean session) throws SQLException{
        String sql = "INSERT INTO training_sessions (session_id, student_name, branch_location, lesson_type, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, session.getSession_id());
            ps.setString(2, session.getStudent_name());
            ps.setString(3, session.getBranch_location());
            ps.setString(4, session.getLesson_type());
            ps.setString(5, session.getStatus());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
    
    public List<SessionBean> getAllSessions(String sql) throws SQLException, Exception{
        List<SessionBean> list = new ArrayList<>();
        String sgl = "SELECT * FROM training_sessions ORDER BY branch_locatio ASC";
        try (Connection conn = getConnection(); 
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()){
            while (rs.next()){
                SessionBean sb = new SessionBean();
                sb.setSession_id(rs.getInt("session_id"));
                sb.setStudent_name(rs.getString("student_name"));
                sb.setBranch_location(rs.getString("branch_location"));
                sb.setLesson_type(rs.getString("lesson_type"));
                sb.setStatus(rs.getString("status"));
                list.add(sb);
        } 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public SessionBean validateLogin(String matricNo, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
